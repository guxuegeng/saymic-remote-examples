# 语麦 · 小米遥控器连接示例

适用于 Windows x64 的小米遥控器基础蓝牙连接示例和离线 ATVV / IMA ADPCM 解码工具。目标型号是 RC001（小米蓝牙遥控器 2）和 RC003（小米蓝牙遥控器 2 Pro）。

## 构建与测试

在 Windows 10 或 Windows 11 x64 上打开命令提示符。项目使用系统安装的 .NET Framework 4.8 C# 编译器和 WinRT 元数据。

```bat
build.cmd
bin\saymic-remote-examples.exe self-test
bin\saymic-remote-examples.exe list
```

`list` 枚举 Windows 可见的已配对和未配对候选设备。设备名用于筛选，只有实际发现 ATVV 服务后才确认可访问该协议。显示为 `xiaomi-unknown` 的设备使用通用名称，不能据此推定型号。

## 连接、配对与通知

在有遥控器的测试机上，唤醒设备并先运行 `list`。以下以 RC001 为例。RC003 使用对应型号参数。

```bat
bin\saymic-remote-examples.exe pair RC001
bin\saymic-remote-examples.exe probe RC001
bin\saymic-remote-examples.exe observe RC001 10
```

- `pair` 只针对唯一匹配的未配对设备。出现配对请求时按 Windows 提示确认。已配对设备可以直接进入 `probe`，也可在 Windows 蓝牙设置中完成配对。
- `probe` 通过非缓存的 GATT 查询发现 ATVV 服务，显示已发现的特征和 Windows 连接状态，然后释放本进程持有的设备及服务句柄。其他应用可能仍在使用同一设备。
- `observe` 在指定时间内订阅 ATVV 控制特征的通知或指示，仅统计接收次数，结束时取消订阅。收到零条表示该观察期间没有事件。建议用空闲测试机观察，避免与已有遥控器应用同时操作。
- Windows 蓝牙栈负责服务发现和配对超时。观察秒数从订阅成功后开始。

## 离线解析与解码

```bat
bin\saymic-remote-examples.exe control 0B010002000000
bin\saymic-remote-examples.exe decode-raw payload.adpcm output.wav 16000 high
```

`control` 解析单条十六进制 ATVV 控制消息。`decode-raw` 的输入是**已提取的连续 IMA ADPCM 载荷**，以 predictor = 0、step index = 0 开始。采样率支持 8000 和 16000 Hz，默认 16000 Hz 和高半字节优先。输出为单声道 16 位 PCM WAV。已有输出文件会保留。带 ATVV 头部或需要从同步消息设置解码状态的录制，须先提取载荷并在调用解码器时设置相应初始状态。

## 验证状态

Windows x64 编译、离线自测、WAV 输出和真实 Windows 蓝牙枚举已验证。RC001、RC003 的实体配对、GATT 通知和释放各自待测。

## 许可证与来源

本示例采用 GPL-3.0-only。上游来自 GetSayAll 及其贡献者。详见 [LICENSE](LICENSE) 和 [ATTRIBUTION.md](ATTRIBUTION.md)。

[语麦官网](https://renxbl.icu/intro/)
