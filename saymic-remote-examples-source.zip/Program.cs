﻿// SPDX-License-Identifier: GPL-3.0-only
using System;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;

internal static class Program
{
    private static int Main(string[] arguments)
    {
        try
        {
            Run(arguments).GetAwaiter().GetResult();
            return 0;
        }
        catch (Exception error)
        {
            // WinRT errors can include device identifiers. Print their numeric code only.
            var expected = error is ArgumentException || error is FormatException || error is InvalidOperationException;
            Console.Error.WriteLine(expected ? error.Message :
                string.Format("{0} (0x{1:X8})", error.GetType().Name, error.HResult));
            return 1;
        }
    }

    private static async Task Run(string[] arguments)
    {
        switch (arguments.Length == 0 ? "help" : arguments[0])
        {
            case "help":
            case "--help":
                Console.WriteLine("list | pair MODEL | probe MODEL | observe MODEL [seconds]");
                Console.WriteLine("control HEX | decode-raw INPUT OUTPUT [16000|8000] [high|low] | self-test");
                Console.WriteLine("MODEL is RC001, RC003, or xiaomi-unknown.");
                break;
            case "list":
                RequireCount(arguments, 1, 1);
                await RemoteConnection.List();
                break;
            case "pair":
                RequireCount(arguments, 2, 2);
                await RemoteConnection.Pair(ParseModel(arguments[1]));
                break;
            case "probe":
                RequireCount(arguments, 2, 2);
                await RemoteConnection.Probe(ParseModel(arguments[1]), 0);
                break;
            case "observe":
                RequireCount(arguments, 2, 3);
                int seconds = arguments.Length == 3 ? int.Parse(arguments[2], CultureInfo.InvariantCulture) : 10;
                if (seconds < 1 || seconds > 30)
                {
                    throw new ArgumentException("Observation duration must be between 1 and 30 seconds.");
                }
                await RemoteConnection.Probe(ParseModel(arguments[1]), seconds);
                break;
            case "control":
                RequireCount(arguments, 2, 2);
                Console.WriteLine(Atvv.Describe(ParseHex(arguments[1])));
                break;
            case "decode-raw":
                RequireCount(arguments, 3, 5);
                Decode(arguments);
                break;
            case "self-test":
                RequireCount(arguments, 1, 1);
                SelfTests.Run();
                break;
            default:
                throw new ArgumentException("Unknown command. Run help to see available commands.");
        }
    }

    private static string ParseModel(string value)
    {
        switch (value.ToUpperInvariant())
        {
            case "RC001": return "RC001";
            case "RC003": return "RC003";
            case "XIAOMI-UNKNOWN": return "xiaomi-unknown";
            default: throw new ArgumentException("Choose RC001, RC003, or xiaomi-unknown.");
        }
    }

    private static void RequireCount(string[] arguments, int minimum, int maximum)
    {
        if (arguments.Length < minimum || arguments.Length > maximum)
        {
            throw new ArgumentException("Unexpected argument count. Run help for usage.");
        }
    }

    private static byte[] ParseHex(string text)
    {
        if (text.Length % 2 != 0)
        {
            throw new FormatException("Hex input must have two digits per byte.");
        }
        var result = new byte[text.Length / 2];
        for (int i = 0; i < result.Length; i++)
        {
            result[i] = byte.Parse(text.Substring(i * 2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
        }
        return result;
    }

    private static void Decode(string[] arguments)
    {
        int rate = arguments.Length >= 4 ? int.Parse(arguments[3], CultureInfo.InvariantCulture) : 16000;
        if (rate != 16000 && rate != 8000)
        {
            throw new ArgumentException("Sample rate must be 16000 or 8000.");
        }
        string order = arguments.Length >= 5 ? arguments[4] : "high";
        if (order != "high" && order != "low")
        {
            throw new ArgumentException("Nibble order must be high or low.");
        }

        byte[] payload;
        using (var stream = File.OpenRead(arguments[1]))
        {
            if (stream.Length < 1 || stream.Length > 16 * 1024 * 1024)
            {
                throw new ArgumentException("Raw ADPCM input must contain 1 byte to 16 MiB.");
            }
            using (var reader = new BinaryReader(stream))
            {
                payload = reader.ReadBytes((int)stream.Length);
            }
        }
        var decoder = new ImaAdpcmDecoder(order == "high");
        short[] samples = decoder.Decode(payload);
        using (var stream = new FileStream(arguments[2], FileMode.CreateNew, FileAccess.Write))
        {
            PcmWave.Write(stream, samples, rate);
        }
        Console.WriteLine("Wrote {0} mono PCM samples at {1} Hz.", samples.Length, rate);
    }
}
