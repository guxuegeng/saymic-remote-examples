﻿// SPDX-License-Identifier: GPL-3.0-only
using System;
using System.IO;
using System.Text;

internal static class Atvv
{
    internal static readonly Guid ServiceUuid = new Guid("AB5E0001-5A21-4F05-BC7D-AF01F617B664");
    internal static readonly Guid TransmitUuid = new Guid("AB5E0002-5A21-4F05-BC7D-AF01F617B664");
    internal static readonly Guid AudioUuid = new Guid("AB5E0003-5A21-4F05-BC7D-AF01F617B664");
    internal static readonly Guid ControlUuid = new Guid("AB5E0004-5A21-4F05-BC7D-AF01F617B664");

    internal static string CharacteristicName(Guid uuid)
    {
        if (uuid == TransmitUuid) return "Transmit";
        if (uuid == AudioUuid) return "Audio";
        if (uuid == ControlUuid) return "Control";
        return null;
    }

    internal static string Describe(byte[] payload)
    {
        RequireLength(payload, 1);
        switch (payload[0])
        {
            case 0x00:
                return "Stream stopped";
            case 0x04:
                return "Stream started, session " + (payload.Length >= 4 ? payload[3] : 0);
            case 0x08:
                return "Microphone open requested";
            case 0x0A:
                RequireLength(payload, 7);
                int predictor = (short)((payload[4] << 8) | payload[5]);
                return string.Format("Decoder sync, predictor {0}, step index {1}", predictor, payload[6]);
            case 0x0B:
                RequireLength(payload, 7);
                int version = (payload[1] << 8) | payload[2];
                if (version < 0x0100) RequireLength(payload, 9);
                int codecs = version < 0x0100 ? payload[4] : payload[3];
                if (version >= 0x0100 && codecs == 0 && payload.Length >= 9 && (payload[4] & 3) != 0)
                {
                    codecs = payload[4];
                }
                int rate = (codecs & 2) != 0 ? 16000 : 8000;
                int size = (payload[5] << 8) | payload[6];
                return string.Format("Capabilities, ATVV 0x{0:X4}, {1} Hz, frame size {2}",
                    version, rate, size == 0 ? 120 : size);
            default:
                return string.Format("Unknown ATVV opcode 0x{0:X2}", payload[0]);
        }
    }

    private static void RequireLength(byte[] payload, int minimum)
    {
        if (payload.Length < minimum)
        {
            throw new FormatException("ATVV control packet is too short.");
        }
    }
}

internal sealed class ImaAdpcmDecoder
{
    private static readonly int[] Steps = {
        7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,
        66,73,80,88,97,107,118,130,143,157,173,190,209,230,253,279,307,337,371,
        408,449,494,544,598,658,724,796,876,963,1060,1166,1282,1411,1552,1707,1878,
        2066,2272,2499,2749,3024,3327,3660,4026,4428,4871,5358,5894,6484,7132,7845,
        8630,9493,10442,11487,12635,13899,15289,16818,18500,20350,22385,24623,27086,
        29794,32767
    };
    private static readonly int[] Adjustments = { -1, -1, -1, -1, 2, 4, 6, 8 };
    private readonly bool highFirst;

    internal int Predictor { get; private set; }
    internal int StepIndex { get; private set; }

    internal ImaAdpcmDecoder(bool highFirst)
    {
        this.highFirst = highFirst;
    }

    internal void Reset(int predictor, int stepIndex)
    {
        Predictor = Clamp(predictor, short.MinValue, short.MaxValue);
        StepIndex = Clamp(stepIndex, 0, Steps.Length - 1);
    }

    internal short[] Decode(byte[] input)
    {
        short[] samples = new short[checked(input.Length * 2)];
        for (int i = 0; i < input.Length; i++)
        {
            int high = input[i] >> 4;
            int low = input[i] & 15;
            samples[2 * i] = ReadNibble(highFirst ? high : low);
            samples[2 * i + 1] = ReadNibble(highFirst ? low : high);
        }
        return samples;
    }

    private short ReadNibble(int nibble)
    {
        int step = Steps[StepIndex];
        int difference = (step >> 3)
            + ((nibble & 1) != 0 ? step >> 2 : 0)
            + ((nibble & 2) != 0 ? step >> 1 : 0)
            + ((nibble & 4) != 0 ? step : 0);
        Predictor = Clamp(Predictor + ((nibble & 8) != 0 ? -difference : difference),
            short.MinValue, short.MaxValue);
        StepIndex = Clamp(StepIndex + Adjustments[nibble & 7], 0, Steps.Length - 1);
        return (short)Predictor;
    }

    private static int Clamp(int value, int minimum, int maximum)
    {
        return Math.Max(minimum, Math.Min(value, maximum));
    }
}

internal static class PcmWave
{
    internal static void Write(Stream output, short[] samples, int sampleRate)
    {
        int bytes = checked(samples.Length * sizeof(short));
        using (var writer = new BinaryWriter(output, Encoding.ASCII, true))
        {
            writer.Write(Encoding.ASCII.GetBytes("RIFF"));
            writer.Write(checked(36 + bytes));
            writer.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
            writer.Write(16);
            writer.Write((short)1);
            writer.Write((short)1);
            writer.Write(sampleRate);
            writer.Write(sampleRate * 2);
            writer.Write((short)2);
            writer.Write((short)16);
            writer.Write(Encoding.ASCII.GetBytes("data"));
            writer.Write(bytes);
            foreach (short sample in samples)
            {
                writer.Write(sample);
            }
        }
    }
}
