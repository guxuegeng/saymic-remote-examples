﻿// SPDX-License-Identifier: GPL-3.0-only
using System;
using System.IO;
using System.Linq;
using System.Text;

internal static class SelfTests
{
    internal static void Run()
    {
        var decoder = new ImaAdpcmDecoder(true);
        Equal(new short[] { 0, 0, 11, -19, -23, -20, -72, -184 },
            decoder.Decode(new byte[] { 0x00, 0x7f, 0x80, 0xff }), "upstream synthetic reference vector");
        decoder.Reset(0, 0);
        Equal(new short[] { 11, -19 }, decoder.Decode(new byte[] { 0x7f }), "high nibble first");
        Equal(new short[] { -11, 19 }, new ImaAdpcmDecoder(false).Decode(new byte[] { 0x7f }), "low nibble first");
        decoder.Reset(100000, 1000);
        Check(decoder.Predictor == short.MaxValue && decoder.StepIndex == 88, "state clamping");
        Equal(new short[] { short.MaxValue, short.MaxValue }, decoder.Decode(new byte[] { 0x77 }), "PCM saturation");
        decoder.Reset(0, 0);
        short[] split = decoder.Decode(new byte[] { 0x11 }).Concat(decoder.Decode(new byte[] { 0x22 })).ToArray();
        Equal(new ImaAdpcmDecoder(true).Decode(new byte[] { 0x11, 0x22 }), split, "state across chunks");

        Check(Atvv.Describe(new byte[] { 0x04, 0, 2, 9 }) == "Stream started, session 9", "ATVV session");
        Check(Atvv.Describe(new byte[] { 0x0A, 0, 0, 0, 0xff, 0xfe, 7 }) ==
            "Decoder sync, predictor -2, step index 7", "signed predictor");
        Check(Atvv.Describe(new byte[] { 0x0B, 1, 0, 2, 0, 0, 0 }).Contains("16000 Hz, frame size 120"),
            "ATVV codec and frame size");
        Check(Atvv.Describe(new byte[] { 0x0B, 1, 0, 0, 2, 0, 64, 0, 0 }).Contains("16000 Hz, frame size 64"),
            "ATVV alternate capabilities");
        Check(Atvv.Describe(new byte[] { 0x0B, 0, 9, 0, 1, 0, 64, 0, 0 }).Contains("8000 Hz, frame size 64"),
            "legacy ATVV codec");
        RejectShort(new byte[0]);
        RejectShort(new byte[] { 0x0A, 0xff });
        RejectShort(new byte[] { 0x0B, 0, 9, 0, 1, 0, 64 });
        Check(Atvv.Describe(new byte[] { 0xfe }) == "Unknown ATVV opcode 0xFE", "unrecognized opcode");

        Check(RemoteConnection.ModelFromName(" Xiaomi Bluetooth Remote 2 ") == "RC001", "RC001 model name");
        Check(RemoteConnection.ModelFromName("Xiaomi Bluetooth Remote 2 Pro") == "RC003", "RC003 model name");
        Check(RemoteConnection.ModelFromName("Mi RC") == "xiaomi-unknown", "ambiguous name");
        Check(RemoteConnection.ModelFromName("Generic remote") == null, "other device name");

        using (var stream = new MemoryStream())
        {
            PcmWave.Write(stream, new short[] { 42, -42 }, 16000);
            byte[] bytes = stream.ToArray();
            Check(bytes.Length == 48 && Encoding.ASCII.GetString(bytes, 0, 4) == "RIFF" &&
                Encoding.ASCII.GetString(bytes, 8, 4) == "WAVE", "WAV header");
            Check(BitConverter.ToInt32(bytes, 4) == 40 && BitConverter.ToInt32(bytes, 40) == 4 &&
                BitConverter.ToInt32(bytes, 24) == 16000 && BitConverter.ToInt16(bytes, 46) == -42, "WAV metadata and samples");
        }
        Console.WriteLine("21 deterministic checks passed (offline decoder, ATVV, WAV and model names).");
    }

    private static void Equal(short[] expected, short[] result, string name)
    {
        Check(expected.SequenceEqual(result), name);
    }

    private static void RejectShort(byte[] payload)
    {
        try
        {
            Atvv.Describe(payload);
        }
        catch (FormatException)
        {
            return;
        }
        throw new InvalidOperationException("Expected a short-packet error.");
    }

    private static void Check(bool success, string name)
    {
        if (!success)
        {
            throw new InvalidOperationException("Self-test failed: " + name);
        }
    }
}
