﻿// SPDX-License-Identifier: GPL-3.0-only
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Devices.Enumeration;
using Windows.Foundation;

internal static class RemoteConnection
{
    private sealed class Candidate
    {
        public DeviceInformation Device { get; private set; }
        public string Model { get; private set; }

        public Candidate(DeviceInformation device, string model)
        {
            Device = device;
            Model = model;
        }
    }

    internal static string ModelFromName(string value)
    {
        switch (value.Trim().ToLowerInvariant())
        {
            case "xiaomi bluetooth remote 2":
            case "小米蓝牙遥控器2":
            case "rc001":
                return "RC001";
            case "xiaomi bluetooth remote 2 pro":
            case "小米蓝牙遥控器2 pro":
            case "arn9":
            case "rc003":
                return "RC003";
            case "mi rc":
            case "小米蓝牙语音遥控器":
                return "xiaomi-unknown";
            default:
                return null;
        }
    }

    // Bridge WinRT completion explicitly so the example builds with the Windows inbox compiler.
    private static Task<T> Complete<T>(IAsyncOperation<T> operation)
    {
        var result = new TaskCompletionSource<T>(TaskCreationOptions.RunContinuationsAsynchronously);
        operation.Completed = (completed, status) =>
        {
            if (status == AsyncStatus.Canceled)
            {
                result.TrySetCanceled();
                return;
            }

            try
            {
                result.TrySetResult(completed.GetResults());
            }
            catch (Exception error)
            {
                result.TrySetException(error);
            }
        };
        return result.Task;
    }

    private static async Task<List<Candidate>> Discover(bool paired)
    {
        string selector = BluetoothLEDevice.GetDeviceSelectorFromPairingState(paired);
        var devices = await Complete(DeviceInformation.FindAllAsync(selector));
        var candidates = new List<Candidate>();
        foreach (DeviceInformation device in devices)
        {
            string model = ModelFromName(device.Name);
            if (model != null)
            {
                candidates.Add(new Candidate(device, model));
            }
        }
        return candidates;
    }

    internal static async Task List()
    {
        foreach (bool paired in new[] { true, false })
        {
            List<Candidate> entries = await Discover(paired);
            Console.WriteLine("{0} candidates: {1}", paired ? "Paired" : "Unpaired", entries.Count);
            foreach (Candidate entry in entries)
            {
                Console.WriteLine("  {0}", entry.Model);
            }
        }
    }

    private static async Task<DeviceInformation> Select(string model, bool paired)
    {
        List<Candidate> candidates = await Discover(paired);
        List<Candidate> matches = candidates.FindAll(candidate => candidate.Model == model);
        if (matches.Count != 1)
        {
            throw new InvalidOperationException(string.Format(
                "Expected exactly one {0} {1} candidate, found {2}. Run list and check Windows Bluetooth settings.",
                paired ? "paired" : "unpaired", model, matches.Count));
        }
        return matches[0].Device;
    }

    internal static async Task Pair(string model)
    {
        DeviceInformation device = await Select(model, false);
        if (!device.Pairing.CanPair)
        {
            throw new InvalidOperationException("Windows reports that this device cannot pair right now.");
        }

        Console.WriteLine("Confirm the pairing request in Windows if prompted.");
        DevicePairingResult result = await Complete(device.Pairing.PairAsync());
        if (result.Status != DevicePairingResultStatus.Paired &&
            result.Status != DevicePairingResultStatus.AlreadyPaired)
        {
            throw new InvalidOperationException("Pairing result: " + result.Status);
        }
        Console.WriteLine("Pairing result: {0}", result.Status);
    }

    internal static async Task Probe(string model, int observeSeconds)
    {
        DeviceInformation candidate = await Select(model, true);
        using (var device = await Complete(BluetoothLEDevice.FromIdAsync(candidate.Id)))
        {
            if (device == null)
            {
                throw new InvalidOperationException("Windows could not open the paired Bluetooth device.");
            }

            var discovery = await Complete(device.GetGattServicesForUuidAsync(Atvv.ServiceUuid, BluetoothCacheMode.Uncached));
            EnsureSuccess("ATVV service discovery", discovery.Status);
            try
            {
                if (discovery.Services.Count != 1)
                {
                    throw new InvalidOperationException("Expected one ATVV service. GATT capability is unverified.");
                }

                var characteristics = await Complete(discovery.Services[0].GetCharacteristicsAsync());
                EnsureSuccess("Characteristic discovery", characteristics.Status);
                GattCharacteristic control = null;
                foreach (GattCharacteristic characteristic in characteristics.Characteristics)
                {
                    string label = Atvv.CharacteristicName(characteristic.Uuid);
                    if (label != null)
                    {
                        Console.WriteLine("{0}: {1}", label, characteristic.CharacteristicProperties);
                    }
                    if (characteristic.Uuid == Atvv.ControlUuid)
                    {
                        control = characteristic;
                    }
                }
                if (control == null)
                {
                    throw new InvalidOperationException("The ATVV control characteristic was not found.");
                }

                Console.WriteLine("ATVV service discovered. Windows status: {0}", device.ConnectionStatus);
                if (observeSeconds > 0)
                {
                    await Observe(control, observeSeconds);
                }
            }
            finally
            {
                foreach (GattDeviceService service in discovery.Services)
                {
                    service.Dispose();
                }
            }
        }
        Console.WriteLine("Released this process's GATT handles.");
    }

    private static void EnsureSuccess(string operation, GattCommunicationStatus status)
    {
        if (status != GattCommunicationStatus.Success)
        {
            throw new InvalidOperationException(operation + " failed: " + status);
        }
    }

    private static async Task Observe(GattCharacteristic control, int seconds)
    {
        var properties = control.CharacteristicProperties;
        var descriptor = GattClientCharacteristicConfigurationDescriptorValue.Notify;
        if (!properties.HasFlag(GattCharacteristicProperties.Notify))
        {
            if (!properties.HasFlag(GattCharacteristicProperties.Indicate))
            {
                throw new InvalidOperationException("The control characteristic supports neither notify nor indicate.");
            }
            descriptor = GattClientCharacteristicConfigurationDescriptorValue.Indicate;
        }

        int count = 0;
        TypedEventHandler<GattCharacteristic, GattValueChangedEventArgs> listener =
            (sender, value) => Interlocked.Increment(ref count);
        control.ValueChanged += listener;
        try
        {
            EnsureSuccess("Enable control notifications",
                await Complete(control.WriteClientCharacteristicConfigurationDescriptorAsync(descriptor)));
            Console.WriteLine("Observing control notifications for {0}s. Notification payloads are ignored.", seconds);
            try
            {
                await Task.Delay(TimeSpan.FromSeconds(seconds));
            }
            finally
            {
                EnsureSuccess("Disable control notifications",
                    Complete(control.WriteClientCharacteristicConfigurationDescriptorAsync(
                        GattClientCharacteristicConfigurationDescriptorValue.None)).GetAwaiter().GetResult());
            }
        }
        finally
        {
            control.ValueChanged -= listener;
        }
        Console.WriteLine("Control notifications received: {0}", Volatile.Read(ref count));
    }
}
