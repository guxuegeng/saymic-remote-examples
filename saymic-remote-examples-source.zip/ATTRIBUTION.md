# 来源与署名

本项目依据 GPL-3.0-only 提供。上游作者为 GetSayAll 及其贡献者，原仓库的署名和 GPL-3.0 许可保留。语麦在 2026-11-21 将下列公开代码中的基础逻辑适配为独立的 Windows C# 示例。

| 公开来源 | 本项目的改动 |
| --- | --- |
| [GetSayAll Windows BLE](https://github.com/GetSayAll/remote-mic-app-windows/blob/1fc5170dcbc23a1bf05ac5d3dcb9c789ca9d1aab/crates/sayall-windows/src/ble.rs) | 参考公开 WinRT 连接、服务发现、通知与句柄释放流程。示例只运行一次显式操作。 |
| [GetSayAll 设备匹配](https://github.com/GetSayAll/remote-mic-app-windows/blob/1fc5170dcbc23a1bf05ac5d3dcb9c789ca9d1aab/crates/sayall-windows/src/lib.rs) | 复用小米型号名称匹配，增加单次枚举与显式选择。 |
| [GetSayAll ATVV](https://github.com/GetSayAll/remote-mic-app-windows/blob/1fc5170dcbc23a1bf05ac5d3dcb9c789ca9d1aab/crates/sayall-core/src/atvv.rs) | 将 UUID、控制消息解析和能力字段移植到 C#，输出适于命令行阅读的摘要。 |
| [GetSayAll ADPCM](https://github.com/GetSayAll/remote-mic-app-windows/blob/1fc5170dcbc23a1bf05ac5d3dcb9c789ca9d1aab/crates/sayall-core/src/adpcm.rs) | 将 IMA ADPCM 解码和合成校验向量移植到 C#，增加 PCM WAV 写入。 |

WinRT 公开 API 的使用参考 [Microsoft Learn GATT 客户端](https://learn.microsoft.com/en-us/windows/apps/develop/devices-sensors/gatt-client) 和 [设备配对](https://learn.microsoft.com/en-us/windows/apps/develop/devices-sensors/pair-devices)。测试数据为合成字节。
