@echo off
setlocal
cd /d "%~dp0" || exit /b 1
set "FRAMEWORK=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
set "METADATA=%WINDIR%\System32\WinMetadata"
set "GAC=%WINDIR%\Microsoft.NET\assembly\GAC_MSIL"
set "CORE_VERSION=v4.0_4.0.0.0__b03f5f7f11d50a3a"
if not exist "%FRAMEWORK%\csc.exe" (
    echo The x64 .NET Framework C# compiler is required. 1>&2
    exit /b 1
)
if not exist bin mkdir bin
"%FRAMEWORK%\csc.exe" /nologo /utf8output /warnaserror+ /target:exe /platform:x64 ^
    /out:bin\saymic-remote-examples.exe ^
    /reference:"%METADATA%\Windows.Devices.winmd" ^
    /reference:"%METADATA%\Windows.Foundation.winmd" ^
    /reference:"%METADATA%\Windows.Storage.winmd" ^
    /reference:"%FRAMEWORK%\System.Runtime.WindowsRuntime.dll" ^
    /reference:"%FRAMEWORK%\System.Runtime.InteropServices.WindowsRuntime.dll" ^
    /reference:"%GAC%\System.Runtime\%CORE_VERSION%\System.Runtime.dll" ^
    /reference:"%GAC%\System.Threading.Tasks\%CORE_VERSION%\System.Threading.Tasks.dll" ^
    /reference:"%GAC%\System.Runtime.InteropServices\%CORE_VERSION%\System.Runtime.InteropServices.dll" ^
    /reference:"%GAC%\System.Collections\%CORE_VERSION%\System.Collections.dll" ^
    /reference:"%GAC%\System.IO\%CORE_VERSION%\System.IO.dll" ^
    Program.cs RemoteConnection.cs OfflineDecoder.cs SelfTests.cs
exit /b %ERRORLEVEL%
